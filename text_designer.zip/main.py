from designer.ascii_designer import generate_ascii_art
from designer.image_designer import create_text_image

def main():
    print("=== Text Designer Project ===")
    text = input("Enter your text: ")

    print("\n--- ASCII Art ---")
    ascii_output = generate_ascii_art(text)
    print(ascii_output)

    print("\n--- Generating Image ---")
    image_path = create_text_image(text, font_path="assets/arial.ttf")
    print(f"Image saved at: {image_path}")

if __name__ == "__main__":
    main()
