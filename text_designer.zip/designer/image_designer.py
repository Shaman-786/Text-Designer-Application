from PIL import Image, ImageDraw, ImageFont
import os

def create_text_image(text, font_path, output_path="output/output.png", font_size=50):
    font = ImageFont.truetype(font_path, font_size)
    width, height = font.getsize(text)

    image = Image.new("RGB", (width + 40, height + 40), color=(255, 255, 255))
    draw = ImageDraw.Draw(image)
    draw.text((20, 20), text, font=font, fill=(0, 0, 0))

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    image.save(output_path)
    return output_path
